# AWS-arduino
Automatic weather station (AWS) model using arduino to send weather station data to remote mongoDB database
